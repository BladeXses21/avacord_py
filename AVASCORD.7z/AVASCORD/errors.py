class NotEnoughMoney(Exception):
    pass


class NotEnoughCP(Exception):
    pass
